Evolution X - By @jarvisdev 

Support Server: https://discord.gg/8svMNKA6nY

Environment Variables

OpenAI Api: https://platform.openai.com/account/api-keys
OpenAI Org Key/ID: https://platform.openai.com/account/org-settings
Image Gen API Key: https://app.prodia.com

# Downloaded from https://nullforums.net/resources/evolution-x-a-multipurpose-discord-bot-v1-4-beta.6782/
# 5627N76VTF